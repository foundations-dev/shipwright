# What Do I Want to Include?

Okay so I've gotten through the Color section of the system just fine. I'm pretty satisfied with my work there. I've also worked through `_font-size.sass` and `_font.sass` in the Typography section, but now I'm at a point where I have to make some decisions that are a little more opinionated and a little less "because it makes sense."

## Headers

